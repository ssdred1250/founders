var UnivLedger = artifacts.require("UnivLedger");

module.exports = function(deployer) {
  deployer.deploy(UnivLedger);
};
